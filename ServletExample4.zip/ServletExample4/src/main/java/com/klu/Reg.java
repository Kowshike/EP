package com.klu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Reg extends GenericServlet {

    private static final long serialVersionUID = 1L;

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        String fname = req.getParameter("fname");
        String lname = req.getParameter("lname");
        String username = req.getParameter("email");
        String pass = req.getParameter("pass");
        RequestDispatcher dis = null;

        try {
            PrintWriter pw = res.getWriter();
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "afroz");

            // Create the Users table if it doesn't exist
            createUsersTableIfNotExists(con);

            boolean userExists = checkUserExists(con, username);

            if (userExists) {
                req.setAttribute("status", "User already exists");
                dis = req.getRequestDispatcher("Register.jsp");
                dis.forward(req, res);
            } else {
                int nextID = getNextID(con);

                // Insert the user into the Users table
                PreparedStatement pq = con.prepareStatement("INSERT INTO Users (id, Fname, Lname, username, pass) VALUES (?, ?, ?, ?, ?)");
                pq.setInt(1, nextID);
                pq.setString(2, fname);
                pq.setString(3, lname);
                pq.setString(4, username);
                pq.setString(5, pass);
                pq.executeUpdate();

                req.setAttribute("status", "Successfully Registered, please login");
                dis = req.getRequestDispatcher("login.jsp");
                dis.forward(req, res);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServletException("Error processing request.");
        }
    }

    private void createUsersTableIfNotExists(Connection con) throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS Users (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "Fname VARCHAR(50), Lname VARCHAR(50), " +
                "username VARCHAR(50), pass VARCHAR(128))";
        try (Statement createTableStmt = con.createStatement()) {
            createTableStmt.execute(createTableSQL);
        }
    }

    private boolean checkUserExists(Connection con, String username) throws SQLException {
        boolean userExists = false;
        try (PreparedStatement checkUserStmt = con.prepareStatement("SELECT * FROM Users WHERE username = ?")) {
            checkUserStmt.setString(1, username);
            try (ResultSet resultSet = checkUserStmt.executeQuery()) {
                if (resultSet.next()) {
                    userExists = true;
                }
            }
        }
        return userExists;
    }

    private int getNextID(Connection con) throws SQLException {
        int nextID = 0;
        try (PreparedStatement maxIdStmt = con.prepareStatement("SELECT MAX(id) FROM Users");
             ResultSet maxid = maxIdStmt.executeQuery()) {
            if (maxid.next()) {
                nextID = maxid.getInt(1) + 1;
            }
        }
        return nextID;
    }
}
