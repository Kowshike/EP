package com.klef.ep.services;

import com.klef.ep.models.Student;

public class StudentServiceImpl implements StudentService
{

	@Override
	public Student CheckStudentLogin(String email, String password) 
	{
		return null;
	}

	@Override
	public Student ViewStudentProfile(int id) 
	{
		return null;
	}

}
